package TutyPackage1;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_ebay {
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver",".\\drivers\\chromedriver.exe");
				
			WebDriver driver = new ChromeDriver();
			driver .get("https://www.ebay.com/");
			driver.manage().window().maximize();
			WebElement tt = driver.findElement(By.xpath("//*[@id=\"gh-ac\"]"));
			tt.sendKeys("iphone 11");
			WebElement uu = driver.findElement(By.xpath("//*[@id=\"gh-btn\"]"));
			uu.click();
			
			System.out.println("Ebay homepage: " + driver.getTitle());
			System.out.println("Ebay homepage URL: " + driver.getCurrentUrl());
			
			System.out.println("\n\n");			
			System.out.println("******Ebay Link Lists*******");
			System.out.println("****************************");
			List<WebElement>  Links = driver.findElements(By.className("s-item__title"));
			
								
			for (int i=0;i<Links.size();i++) {
				WebElement E2 = Links.get(i);
				System.out.println(E2.getText().toCharArray());
				
			}
			
			System.out.println("\n\n");
			System.out.println("******Ebay Link URLs*******");
			System.out.println("****************************");
			List<WebElement> LinksURL = driver.findElements(By.className("s-item__link"));
			
			for(int i=0;i<LinksURL.size();i++) {
				WebElement E3 = LinksURL.get(i);
				if(E3.getAttribute(" _sp") !=null && E3.getAttribute("href").contains("iPhone")); {
					System.out.println(E3.getAttribute("href"));
				}
				
			}
			
			System.out.println("\n\n");
			System.out.println("*****Ebay Link Prices*****");
			List<WebElement>  Price = driver.findElements(By.className("s-item__price"));
			String[] BS_Price = new String[Price.size()];
			
			for(int i=0;i<Price.size();i++) {
				BS_Price[i]= Price.get(i).getText();
				}
			
			System.out.println("*****Price Before Sort*****");
			Print(BS_Price);
			
			Arrays.sort(BS_Price);
			System.out.println("\n\n");
			System.out.println("*****Price After Sort*****");
			Print(BS_Price);
			driver.close();
			}
	
			
		private static void Print(String[] ar)
		{
			for (int i=0; i<ar.length;i++) 
			{
				System.out.println(ar[i]);
			}
		}
		
		
	
}