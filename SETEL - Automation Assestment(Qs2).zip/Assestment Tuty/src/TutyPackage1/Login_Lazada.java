package TutyPackage1;


//import java.text.NumberFormat;
import java.util.Arrays;
import java.util.List;
//import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Lazada {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver",".\\drivers\\chromedriver.exe");
				
			WebDriver driver = new ChromeDriver();
			driver .get("https://lazada.com.my/");
			driver.manage().window().maximize();
			WebElement textSearch = driver.findElement(By.id("q"));
			textSearch.sendKeys("iphone 11");
			driver.findElement(By.className("search-box__button--1oH7")).click();
			
		System.out.println("Lazada homepage: " + driver.getTitle());
		System.out.println("Lazada homepage URL: " + driver.getCurrentUrl());
		System.out.println("\n\n");
		System.out.println("******Lazada Link Lists*******");
		System.out.println("******************************");
		List<WebElement>  Links = driver.findElements(By.className("c16H9d"));
				
		for (int i=0;i<Links.size();i++) {
			WebElement E2 = Links.get(i);
			System.out.println(E2.getText());
			
		}
		/*System.out.println("\n\n");
		System.out.println("******Lazada Link Before URL*******");
		System.out.println("***********************************");
		List<WebElement> LinksURL = driver.findElements(By.tagName("a"));
		
		for(int i=0;i<LinksURL.size();i++) {
			WebElement E3 = LinksURL.get(i);
			if(E3.getAttribute("href") !=null && E3.getAttribute("href").contains("search=1")) {
				System.out.println(E3.getAttribute("href"));
			}
			
		}*/
		System.out.println("\n\n");
		System.out.println("******Lazada Link URLs*******");
		System.out.println("*****************************");
		List<WebElement> uniqueLinks = driver.findElements(By.xpath("//a[contains(@href,'search=1')][not(@href = following::a/@href)]"));
		for(int i=0;i<uniqueLinks.size();i++) {
			WebElement E3 = uniqueLinks.get(i);
			if(E3.getAttribute("href") !=null && E3.getAttribute("href").contains("search=1")) {
				System.out.println(E3.getAttribute("href"));
			}
			
		}
		
		System.out.println("\n\n");			
		System.out.println("******Lazada Link Price*******");
		List<WebElement>  Price = driver.findElements(By.className("c3gUW0"));
		
		String[] BS_Price = new String[Price.size()];
				
				
		for(int i=0;i<Price.size();i++) {
			BS_Price[i]= Price.get(i).getText();
			}
	
		System.out.println("*****Price Before Sort*****");
		System.out.println("***************************");
		Print(BS_Price);
		
				
		Arrays.sort(BS_Price);
		//Arrays.toString(BS_Price);
		System.out.println("\n\n");
		System.out.println("*****Price After Sort*****");
		System.out.println("**************************");
		
		Print(BS_Price);
		driver.close();
			
									
	}



	private static void Print(String[] ar) {
		for (int i=0; i<ar.length;i++) {
			System.out.println(ar[i]);
		}
		// TODO Auto-generated method stub
		
	}
	

	
}
